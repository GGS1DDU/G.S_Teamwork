package ELMS.vo;
/**
 * 功能:快递员能查看的订单信息。
 * 作者:郑闻昊
 */

public class OrdertoCourierVO {

}
