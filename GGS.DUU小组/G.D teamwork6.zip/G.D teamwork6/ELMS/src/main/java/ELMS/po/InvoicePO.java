package ELMS.po;

public class InvoicePO {
	String id;
	public String getID(){
		return id;
	}
}
