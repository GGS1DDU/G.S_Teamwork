package ELMS.po;

public class MemberPO {

}
