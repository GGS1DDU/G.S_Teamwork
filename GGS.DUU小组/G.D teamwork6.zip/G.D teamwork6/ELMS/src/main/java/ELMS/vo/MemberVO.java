package ELMS.vo;

public class MemberVO {

}
